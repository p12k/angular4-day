# AngularMarlabs

This repo consists of all the supporting files - codes, assessments, assignments, referencces for the Angular training conducted at Marlabs from 15 -19th july.  
